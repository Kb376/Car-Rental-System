// Sample data for car inventory
const carData = {
    SUV: [
        { make: "Toyota", model: "RAV4", price: 70 },
        { make: "Ford", model: "Explorer", price: 85 },
    ],
    Trucks: [
        { make: "Ford", model: "F-150", price: 80 },
        { make: "Chevrolet", model: "Silverado 1500", price: 85 },
    ],
    Luxury: [
        { make: "BMW", model: "5 Series", price: 120 },
        { make: "Mercedes-Benz", model: "E-Class", price: 130 },
    ],
    "4Door": [
        { make: "Honda", model: "Accord", price: 60 },
        { make: "Toyota", model: "Camry", price: 65 },
    ],
    "2Door": [
        { make: "Ford", model: "Mustang", price: 90 },
        { make: "Chevrolet", model: "Camaro", price: 95 },
    ],
    MiniVan: [
        { make: "Honda", model: "Odyssey", price: 80 },
        { make: "Chrysler", model: "Pacifica", price: 85 },
    ],
};

// Contact client function
function contactClient() {
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const IDNumber = document.getElementById('IDNumber').value;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const email = document.getElementById('email').value;

    if (firstName && lastName && IDNumber && (phoneNumber || email)) {
        document.getElementById('contactSection').style.display = 'none';
        document.getElementById('availabilitySection').style.display = 'block';
    } else {
        alert("Please fill in required fields.");
    }
}

// Check availability function
function checkAvailability() {
    const carType = document.getElementById("carType").value;
    const availableCarsDiv = document.getElementById("availableCars");
    const selectedCarDropdown = document.getElementById("selectedCar");
    const reservationForm = document.getElementById("reservationForm");

    // Clear previous results
    availableCarsDiv.innerHTML = "";
    selectedCarDropdown.innerHTML = "<option value=''>Select a car</option>"; // Reset dropdown
    reservationForm.style.display = "none"; // Hide reservation form initially

    // Check if the selected car type has available cars
    if (carType && carData[carType]) {
        const cars = carData[carType];
        let carInfoHtml = `<h3>Available ${carType} Cars:</h3>`;
        cars.forEach((car, index) => {
            carInfoHtml += `
                <p>Make: ${car.make}<br>
                Model: ${car.model}<br>
                Average Rental Price: $${car.price}/day</p>`;
            
            // Add car options to the reservation dropdown
            selectedCarDropdown.innerHTML += `<option value="${index}">${car.make} ${car.model}</option>`;
        });
        availableCarsDiv.innerHTML = carInfoHtml;

        // Show the reservation form
        reservationForm.style.display = "block";
    } else {
        availableCarsDiv.innerHTML = "<p>No available cars for this category.</p>";
    }
}

// Apply discount function
function applyDiscount() {
    alert("Discount code applied! 25% off.");
}

// Process and confirm payment
function confirmPayment() {
    document.getElementById('confirmationSection').style.display = 'none';
    document.getElementById('invoiceSection').style.display = 'block';
    generateInvoice();
}

// Generate invoice
function generateInvoice() {
    document.getElementById('invoiceDetails').innerHTML = `
        <p>Invoice generated with customer and car details.</p>
    `;
}

// Cancel reservation function
function cancelReservation() {
    if (confirm("Are you sure you want to cancel? All information will be lost.")) {
        document.location.reload();
    }
}

// Function to handle reservation submission
function submitReservation(event) {
    event.preventDefault(); // Prevent the default form submission

    const selectedCarIndex = document.getElementById("selectedCar").value;
    const carType = document.getElementById("carType").value;

    if (selectedCarIndex !== "") {
        const selectedCar = carData[carType][selectedCarIndex];
        alert(`Reservation successful!\n\nYou have reserved:\n${selectedCar.make} ${selectedCar.model}\nAverage Rental Price: $${selectedCar.price}/day`);
    } else {
        alert("Please select a car to reserve.");
    }
}