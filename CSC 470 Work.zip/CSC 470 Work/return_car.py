import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta


class ReturnRental:
    def __init__(self, root, is_logged_in, role):
        self.root = root
        self.root.title("Return Rental Car")
        self.root.geometry("600x400")

        # Check if the user is logged in
        if not is_logged_in:
            messagebox.showerror("Access Denied", "You must log in to access this feature.")
            self.root.destroy()  # Close the window
            return

        self.role = role  # Admin or Staff role

        # Simulated rental records
        self.rentals = [
            {"rental_id": "R001", "car": "Toyota Camry", "due_date": "2023-12-10", "daily_rate": 50, "is_returned": False},
            {"rental_id": "R002", "car": "Honda Civic", "due_date": "2023-12-15", "daily_rate": 40, "is_returned": False},
            {"rental_id": "R003", "car": "Ford Focus", "due_date": "2023-12-12", "daily_rate": 45, "is_returned": False},
        ]

        self.return_rental_menu()

    def return_rental_menu(self):
        """Display the main menu for returning a rental car."""
        self.clear_screen()

        tk.Label(self.root, text="Return Rental Car", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(self.root, text="Enter Rental ID:", font=("Arial", 12)).pack(pady=5)
        self.rental_id_entry = tk.Entry(self.root)
        self.rental_id_entry.pack(pady=5)

        tk.Button(self.root, text="Check Rental", command=self.check_rental).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.close_return_menu).pack(pady=10)

    def check_rental(self):
        """Check if the rental ID exists and display return details."""
        rental_id = self.rental_id_entry.get().strip()

        if not rental_id:
            messagebox.showwarning("Input Error", "Please enter a rental ID.")
            return

        rental = next((rental for rental in self.rentals if rental["rental_id"] == rental_id), None)

        if not rental:
            messagebox.showerror("Not Found", "Rental ID not found.")
            return

        if rental["is_returned"]:
            messagebox.showinfo("Already Returned", f"The car ({rental['car']}) has already been returned.")
            return

        self.show_return_details(rental)

    def show_return_details(self, rental):
        """Display details of the rental and calculate fees."""
        self.clear_screen()

        tk.Label(self.root, text=f"Rental ID: {rental['rental_id']}", font=("Arial", 12)).pack(pady=5)
        tk.Label(self.root, text=f"Car: {rental['car']}", font=("Arial", 12)).pack(pady=5)
        tk.Label(self.root, text=f"Due Date: {rental['due_date']}", font=("Arial", 12)).pack(pady=5)

        # Calculate late fees if the car is returned late
        due_date = datetime.strptime(rental["due_date"], "%Y-%m-%d")
        return_date = datetime.now()
        late_days = (return_date - due_date).days
        late_fee = max(0, late_days) * rental["daily_rate"]

        tk.Label(self.root, text=f"Daily Rate: ${rental['daily_rate']}", font=("Arial", 12)).pack(pady=5)

        if late_fee > 0:
            tk.Label(self.root, text=f"Late Fee: ${late_fee} ({late_days} days late)", font=("Arial", 12), fg="red").pack(pady=5)
        else:
            tk.Label(self.root, text="No Late Fees", font=("Arial", 12), fg="green").pack(pady=5)

        # Total Bill
        total_bill = rental["daily_rate"] + late_fee
        tk.Label(self.root, text=f"Total Bill: ${total_bill}", font=("Arial", 12, "bold")).pack(pady=10)

        tk.Button(self.root, text="Confirm Return", command=lambda: self.confirm_return(rental, late_fee, total_bill)).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.return_rental_menu).pack(pady=10)

    def confirm_return(self, rental, late_fee, total_bill):
        """Mark the rental as returned and display confirmation."""
        rental["is_returned"] = True
        messagebox.showinfo("Return Confirmed", f"The car ({rental['car']}) has been successfully returned.")
        if late_fee > 0:
            messagebox.showinfo("Late Fee", f"Late Fee Charged: ${late_fee}")
        messagebox.showinfo("Total Bill Paid", f"Total Amount Paid: ${total_bill}")
        self.return_rental_menu()

    def close_return_menu(self):
        """Close the return rental menu."""
        self.root.destroy()

    def clear_screen(self):
        """Clear the current screen."""
        for widget in self.root.winfo_children():
            widget.destroy()


# Run this file directly for testing
if __name__ == "__main__":
    from Login import CarRentalSystem  # Import your login system

    root = tk.Tk()
    login_app = CarRentalSystem(root)
    root.mainloop()

    if login_app.logged_in:  # Check login status
        role = login_app.users[login_app.username]["role"]  # Get user role
        root = tk.Tk()
        ReturnRental(root, login_app.logged_in, role)
        root.mainloop()
