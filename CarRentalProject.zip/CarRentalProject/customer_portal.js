// Sample data for rentals (to simulate a database)
const rentals = [
    { firstName: 'John', lastName: 'Doe', fileNumber: '001', carType: 'SUV', rentalStart: '2024-10-01', returnDate: '2024-10-05', pricePaid: 150 },
    { firstName: 'Jane', lastName: 'Smith', fileNumber: '002', carType: 'Coupe', rentalStart: '2024-10-10', returnDate: '2024-10-15', pricePaid: 200 }
];

// Search file function
function searchFile() {
    const firstName = document.getElementById('searchFirstName').value;
    const lastName = document.getElementById('searchLastName').value;
    const fileNumber = document.getElementById('searchFileNumber').value;

    const foundRental = rentals.find(rental => rental.firstName === firstName && rental.lastName === lastName && rental.fileNumber === fileNumber);

    if (foundRental) {
        document.getElementById('searchResults').innerHTML = `
            <p>Name: ${foundRental.firstName} ${foundRental.lastName}</p>
            <p>Car Type: ${foundRental.carType}</p>
            <p>Rental Start: ${foundRental.rentalStart}</p>
            <p>Return Date: ${foundRental.returnDate}</p>
            <p>Price Paid: $${foundRental.pricePaid}</p>
        `;
    } else {
        document.getElementById('searchResults').innerHTML = "<p>No rental found.</p>";
    }
}

// Cancel reservation function
function cancelReservation() {
    if (confirm("Are you sure you want to cancel? All information will be lost.")) {
        document.location.reload();
    }
}
