// inventory.js

// Sample data for available cars
const carData = {
    SUV: [
        { make: "Toyota", model: "RAV4", price: 70 },
        { make: "Ford", model: "Explorer", price: 85 },
    ],
    Trucks: [
        { make: "Ford", model: "F-150", price: 80 },
        { make: "Chevrolet", model: "Silverado 1500", price: 85 },
    ],
    Luxury: [
        { make: "BMW", model: "5 Series", price: 120 },
        { make: "Mercedes-Benz", model: "E-Class", price: 130 },
    ],
    "4Door": [
        { make: "Honda", model: "Accord", price: 60 },
        { make: "Toyota", model: "Camry", price: 65 },
    ],
    "2Door": [
        { make: "Ford", model: "Mustang", price: 90 },
        { make: "Chevrolet", model: "Camaro", price: 95 },
    ],
    MiniVan: [
        { make: "Honda", model: "Odyssey", price: 80 },
        { make: "Chrysler", model: "Pacifica", price: 85 },
    ],
};

// Function to check availability and display available cars
function checkAvailability() {
    const carType = document.getElementById("carType").value;
    const availableCarsDiv = document.getElementById("availableCars");

    // Clear previous results
    availableCarsDiv.innerHTML = "";

    // Check if the selected car type has available cars
    if (carType && carData[carType]) {
        const cars = carData[carType];
        let carInfoHtml = `<h3>Available ${carType} Cars:</h3>`;
        cars.forEach(car => {
            carInfoHtml += `
                <p>Make: ${car.make}<br>
                Model: ${car.model}<br>
                Average Rental Price: $${car.price}/day</p>`;
        });
        availableCarsDiv.innerHTML = carInfoHtml;
    } else {
        availableCarsDiv.innerHTML = "<p>No available cars for this category.</p>";
    }
}

// Cancel reservation function
function cancelReservation() {
    if (confirm("Are you sure you want to cancel? All information will be lost.")) {
        document.location.reload();
    }
}
