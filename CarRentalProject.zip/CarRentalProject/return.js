// return.js

// Sample data for logged reservations (for demonstration)
const reservations = {
    1234: {
        firstName: "Jamison",
        lastName: "Williams",
        car: "Toyota RAV4",
        rentalStart: "2024-10-01",
        returnDate: "2024-10-10",
        pricePaid: 700 // Example total price
    }
};

// Function to log the return
function logReturn(event) {
    event.preventDefault(); // Prevent the default form submission

    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const fileNumber = document.getElementById("fileNumber").value;

    const reservation = reservations[fileNumber];

    if (reservation && reservation.firstName === firstName && reservation.lastName === lastName) {
        // Display the car details for the return process
        const carDetailsText = `
            Car: ${reservation.car}<br>
            Rental Start Date: ${reservation.rentalStart}<br>
            Return Date: ${reservation.returnDate}<br>
            Price Paid: $${reservation.pricePaid}
        `;
        document.getElementById("carDetails").innerHTML = carDetailsText;
        document.getElementById("returnDetails").style.display = "block";
    } else {
        alert("No matching reservation found. Please check your details.");
    }
}

// Function to inspect the car for damages
function inspectCar() {
    const damageReported = confirm("Are there any damages to report?");
    if (damageReported) {
        alert("Please make a note of the damages and inform the staff.");
    }

    // Update the status of the vehicle
    updateStatus();
}

// Function to update the vehicle status
function updateStatus() {
    alert("Vehicle status updated: The car has been returned successfully!");
}
