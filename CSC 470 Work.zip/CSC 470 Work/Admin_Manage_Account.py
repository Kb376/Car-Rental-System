import tkinter as tk
from tkinter import ttk, messagebox
from customer_data import customers, next_customer_id  # Import customer data
import re  # For email validation


class ManageCustomerAccount:
    def __init__(self, root):
        self.root = root
        self.root.title("Manage Customer Accounts")
        self.root.geometry("800x600")  # Adjusted for better layout

        # Use the imported customer data
        self.customers = customers
        self.next_customer_id = next_customer_id

        # Build the UI
        self.build_ui()

    def build_ui(self):
        """Construct the user interface."""
        # Header
        tk.Label(self.root, text="Customer Account Management", font=("Helvetica", 16, "bold")).pack(pady=10)

        # Form Section
        form_frame = tk.Frame(self.root, bd=2, relief="groove", padx=10, pady=10)
        form_frame.pack(pady=10, fill="x", padx=20)

        self.create_form(form_frame)

        # Table Section
        self.table_frame = tk.Frame(self.root, bd=2, relief="groove", padx=10, pady=10)
        self.table_frame.pack(pady=10, fill="both", expand=True, padx=20)

        self.create_table(self.table_frame)

        # Action Buttons
        self.create_action_buttons()

        # Load customers into the table
        self.load_customers()

    def create_form(self, parent):
        """Create form inputs for customer details."""
        tk.Label(parent, text="Name:").grid(row=0, column=0, sticky="w", pady=5, padx=5)
        self.name_entry = tk.Entry(parent)
        self.name_entry.grid(row=0, column=1, pady=5, padx=5)

        tk.Label(parent, text="Phone:").grid(row=1, column=0, sticky="w", pady=5, padx=5)
        self.phone_entry = tk.Entry(parent)
        self.phone_entry.grid(row=1, column=1, pady=5, padx=5)

        tk.Label(parent, text="Email:").grid(row=2, column=0, sticky="w", pady=5, padx=5)
        self.email_entry = tk.Entry(parent)
        self.email_entry.grid(row=2, column=1, pady=5, padx=5)

        tk.Button(parent, text="Add Customer", command=self.add_customer, bg="#007BFF", fg="white").grid(row=3, column=0, columnspan=2, pady=10)

    def create_table(self, parent):
        """Create the customer details table."""
        instructions = tk.Label(parent, text="Double-click a customer to edit their details.", font=("Helvetica", 10, "italic"), fg="gray")
        instructions.pack(anchor="w", pady=5)

        self.customer_table = ttk.Treeview(parent, columns=("ID", "Name", "Phone", "Email"), show="headings")
        self.customer_table.heading("ID", text="ID")
        self.customer_table.heading("Name", text="Name")
        self.customer_table.heading("Phone", text="Phone")
        self.customer_table.heading("Email", text="Email")
        self.customer_table.column("ID", width=50)
        self.customer_table.column("Name", width=200)
        self.customer_table.column("Phone", width=150)
        self.customer_table.column("Email", width=200)
        self.customer_table.pack(fill="both", expand=True)

        # Bind table row selection event
        self.customer_table.bind("<Double-1>", self.select_customer)

    def create_action_buttons(self):
        """Create buttons for modifying or deleting customers."""
        action_frame = tk.Frame(self.root, padx=10, pady=10)
        action_frame.pack(fill="x", pady=10, padx=20)

        tk.Button(action_frame, text="Modify Customer", command=self.update_customer, bg="#28A745", fg="white").pack(side="left", padx=10)
        tk.Button(action_frame, text="Delete Customer", command=self.delete_customer, bg="#DC3545", fg="white").pack(side="right", padx=10)

    def load_customers(self):
        """Load all customer records into the table."""
        for row in self.customer_table.get_children():
            self.customer_table.delete(row)

        for customer_id, customer in self.customers.items():
            self.customer_table.insert("", "end", values=(customer_id, customer["name"], customer["phone"], customer["email"]))

    def add_customer(self):
        """Add a new customer."""
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        email = self.email_entry.get().strip()

        # Validate fields
        if not self.validate_fields(name, phone, email):
            return

        # Add customer
        self.customers[self.next_customer_id] = {"name": name, "phone": phone, "email": email}
        self.next_customer_id += 1
        messagebox.showinfo("Success", "Customer added successfully!")
        self.clear_form()
        self.load_customers()

    def update_customer(self):
        """Update the selected customer's information."""
        selected_item = self.customer_table.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select a customer to update.")
            return

        # Retrieve customer ID
        customer_id = self.customer_table.item(selected_item)["values"][0]

        # Get form data
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        email = self.email_entry.get().strip()

        # Validate fields
        if not self.validate_fields(name, phone, email, customer_id):
            return

        # Update customer
        self.customers[customer_id] = {"name": name, "phone": phone, "email": email}
        messagebox.showinfo("Success", "Customer updated successfully!")
        self.clear_form()
        self.load_customers()

    def delete_customer(self):
        """Delete the selected customer."""
        selected_item = self.customer_table.selection()
        if not selected_item:
            messagebox.showerror("Error", "Select a customer to delete.")
            return

        customer_id = self.customer_table.item(selected_item)["values"][0]

        confirm = messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this customer?")
        if confirm:
            del self.customers[customer_id]
            messagebox.showinfo("Success", "Customer deleted successfully!")
            self.load_customers()

    def select_customer(self, event):
        """Load selected customer's data into the form."""
        selected_item = self.customer_table.selection()
        if not selected_item:
            return

        customer = self.customer_table.item(selected_item)["values"]
        self.name_entry.delete(0, tk.END)
        self.name_entry.insert(0, customer[1])
        self.phone_entry.delete(0, tk.END)
        self.phone_entry.insert(0, customer[2])
        self.email_entry.delete(0, tk.END)
        self.email_entry.insert(0, customer[3])

    def clear_form(self):
        """Clear the form fields."""
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)

    def validate_fields(self, name, phone, email, exclude_id=None):
        """Validate form fields for name, phone, and email."""
        if not name or not phone or not email:
            messagebox.showerror("Error", "All fields are required.")
            return False

        if len(name) < 2:
            messagebox.showerror("Error", "Name must be at least 2 characters long.")
            return False

        if not phone.isdigit() or len(phone) != 10:
            messagebox.showerror("Error", "Phone must be a 10-digit number.")
            return False

        if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            messagebox.showerror("Error", "Email must be in a valid format (e.g., user@example.com).")
            return False

        for cust_id, customer in self.customers.items():
            if (customer["phone"] == phone or customer["email"] == email) and cust_id != exclude_id:
                messagebox.showerror("Error", "Phone or Email must be unique.")
                return False

        return True


# Run the app for testing
if __name__ == "__main__":
    root = tk.Tk()
    app = ManageCustomerAccount(root)
    root.mainloop()