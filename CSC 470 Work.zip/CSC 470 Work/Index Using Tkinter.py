import tkinter as tk
from tkinter import messagebox
from LoginTest1 import open_login

def open_reservation():
    messagebox.showinfo("Navigation", "Navigating to Reservations page...")

def open_return():
    messagebox.showinfo("Navigation", "Navigating to Returns page...")

def open_inventory():
    messagebox.showinfo("Navigation", "Navigating to Inventory Management page...")

def open_customer_portal():
    messagebox.showinfo("Navigation", "Navigating to Customer Portal page...")

# Main Window
root = tk.Tk()
root.title("Rental Car System - Home")
root.geometry("600x400")
root.resizable(False, False)

# Header
header_frame = tk.Frame(root)
header_frame.pack(pady=20)

header_label = tk.Label(header_frame, text="Welcome to the Rental Car System", font=("Helvetica", 16, "bold"))
header_label.pack()

subheader_label = tk.Label(header_frame, text="Select an option below to get started", font=("Helvetica", 12))
subheader_label.pack()

# Card Container
card_container = tk.Frame(root)
card_container.pack(pady=20)

# Card Function
def create_card(parent, title, description, command):
    card = tk.Frame(parent, relief="raised", borderwidth=2, padx=10, pady=10)
    card.pack(side="left", padx=10, pady=10)

    title_label = tk.Label(card, text=title, font=("Helvetica", 14, "bold"))
    title_label.pack(pady=5)

    description_label = tk.Label(card, text=description, wraplength=150, justify="center")
    description_label.pack(pady=5)

    button = tk.Button(card, text="Go", command=command, bg="#007BFF", fg="white", font=("Helvetica", 10))
    button.pack(pady=5)

# Cards
create_card(card_container, "Login", "Click here to login", open_login)
create_card(card_container, "Make a Reservation", "Create new reservations for clients.", open_reservation)
create_card(card_container, "Return a Car", "Process vehicle returns efficiently.", open_return)
create_card(card_container, "Inventory Management", "Track and update vehicle inventory.", open_inventory)
create_card(card_container, "Customer Portal", "Access client information and rental history.", open_customer_portal)

# Footer
footer_frame = tk.Frame(root)
footer_frame.pack(pady=20)

footer_label = tk.Label(footer_frame, text="© 2024 Car Rental System", font=("Helvetica", 10))
footer_label.pack()

footer_link = tk.Button(footer_frame, text="Back to Homepage", command=root.quit, fg="blue", font=("Helvetica", 10))
footer_link.pack()

# Run the App
root.mainloop()
