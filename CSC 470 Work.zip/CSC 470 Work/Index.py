import tkinter as tk
from tkinter import messagebox
from Class_Login import CarRentalSystem  # Import the login system
from Car_Availability import CarAvailability  # Import the car availability checker
from Rental_Report import RentalReports  # Import the rental reports module
from return_car import ReturnRental  # Import the return rental module
from GenerateBill import GenerateBill  # Import the generate bill module
from Staff_Manages_Car_Account import CarRentalAdminGUI  # Import the staff manages car account module
from Admin_Manage_Account import ManageCustomerAccount  # Import the admin manages customer account module
from class_Reservation import reservation_gui  # Import the reservation GUI


# Navigation Functions
def open_login():
    """Open the Login Window."""
    login_root = tk.Toplevel(root)
    CarRentalSystem(login_root)


def open_car_availability():
    """Open the Car Availability Window."""
    availability_root = tk.Toplevel(root)
    CarAvailability(availability_root)


def open_rental_reports():
    """Open the Rental Reports Window."""
    reports_root = tk.Toplevel(root)
    RentalReports(reports_root, True, "Admin")  # Assuming logged-in status and Admin role


def open_return_rental():
    """Open the Return Rental Window."""
    return_root = tk.Toplevel(root)
    ReturnRental(return_root, True, "Staff")  # Assuming logged-in status and Staff role


def open_generate_bill():
    """Open the Generate Bill Window."""
    bill_root = tk.Toplevel(root)
    GenerateBill(bill_root, True, "Staff")  # Assuming logged-in status and Staff role


def open_manage_cars():
    """Open the Staff Manages Car Account Window."""
    manage_cars_root = tk.Toplevel(root)
    CarRentalAdminGUI(manage_cars_root, logged_in=True, role="Staff")  # Assuming logged-in status and Staff role


def open_manage_customers():
    """Open the Admin Manage Customer Accounts Window."""
    manage_customers_root = tk.Toplevel(root)
    ManageCustomerAccount(manage_customers_root)  # Assuming logged-in status and Admin role


def open_reservation():
    """Open the Reservation System."""
    reservation_gui()


# Main Window
root = tk.Tk()
root.title("Rental Car System - Home")
root.geometry("1200x800")  # Adjusted size for better layout
root.resizable(False, False)

# Header
header_frame = tk.Frame(root)
header_frame.pack(pady=5)  # Reduced top padding

header_label = tk.Label(header_frame, text="Welcome to the Rental Car System", font=("Helvetica", 18, "bold"))
header_label.pack()

subheader_label = tk.Label(header_frame, text="Select an option below to get started", font=("Helvetica", 12))
subheader_label.pack()

# Card Container
card_container = tk.Frame(root)
card_container.pack(pady=10)  # Reduced padding here as well

# Card Function
def create_card(parent, row, col, title, description, command):
    """Helper function to create navigation cards."""
    card = tk.Frame(parent, relief="raised", borderwidth=2, padx=15, pady=15, width=200, height=150)
    card.grid(row=row, column=col, padx=25, pady=25)

    title_label = tk.Label(card, text=title, font=("Helvetica", 14, "bold"))
    title_label.pack(pady=5)

    description_label = tk.Label(card, text=description, wraplength=180, justify="center")
    description_label.pack(pady=10)

    button = tk.Button(card, text="Go", command=command, bg="#007BFF", fg="white", font=("Helvetica", 10))
    button.pack(pady=5)


# Cards (Grid Layout with 3 cards per row)
create_card(card_container, 0, 0, "Login", "Click here to login", open_login)
create_card(card_container, 0, 1, "Car Availability", "Check car availability by make, model, and dates.", open_car_availability)
create_card(card_container, 0, 2, "Rental Reports", "Generate reports for rentals and revenue.", open_rental_reports)
create_card(card_container, 1, 0, "Return Rental", "Return a car and update rental records.", open_return_rental)
create_card(card_container, 1, 1, "Generate Bill", "Create and manage bills for returned cars.", open_generate_bill)
create_card(card_container, 1, 2, "Manage Cars", "Manage car availability and accounts.", open_manage_cars)
create_card(card_container, 2, 0, "Manage Customers", "Manage customer accounts and details.", open_manage_customers)
create_card(card_container, 2, 1, "Make a Reservation", "Create new reservations for clients.", open_reservation)

# Footer
footer_frame = tk.Frame(root)
footer_frame.pack(pady=5)

footer_label = tk.Label(footer_frame, text="© 2024 Car Rental System", font=("Helvetica", 10))
footer_label.pack()

footer_link = tk.Button(footer_frame, text="Back to Homepage", command=root.quit, fg="blue", font=("Helvetica", 10))
footer_link.pack()

# Run the App
root.mainloop()
