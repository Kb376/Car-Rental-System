# In-memory dictionary to store customer data
customers = {
    1: {"name": "John Doe", "phone": "1234567890", "email": "johndoe@example.com"},
    2: {"name": "Jane Smith", "phone": "9876543210", "email": "janesmith@example.com"},
    3: {"name": "Bob Johnson", "phone": "5556667777", "email": "bobjohnson@example.com"}
}

# Next available customer ID
next_customer_id = max(customers.keys()) + 1 if customers else 1
