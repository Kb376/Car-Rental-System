import tkinter as tk
from tkinter import messagebox
from datetime import datetime
import csv


class RentalReport:
    def __init__(self, root, login_state):
        """
        Initialize the Rental Report Generator.
        :param root: The parent Tkinter window.
        :param login_state: A dictionary containing login state (is_logged_in, role, username).
        """
        self.root = root
        self.root.title("Rental Report Generator")
        self.root.geometry("400x300")

        # Check login state
        if not login_state["is_logged_in"]:
            messagebox.showerror("Login Required", "Please log in to access this feature.")
            self.root.destroy()
            return

        if login_state["role"] != "Admin":
            messagebox.showerror("Access Denied", "Only Admin users can access this feature.")
            self.root.destroy()
            return

        # Display the UI
        self.create_ui()

    def create_ui(self):
        """Create the Rental Report Generator UI."""
        tk.Label(self.root, text="Generate Rental Report", font=("Helvetica", 16, "bold")).pack(pady=10)
        tk.Label(self.root, text="Enter a date range to generate the report", font=("Helvetica", 12)).pack(pady=5)

        # Date Inputs
        input_frame = tk.Frame(self.root)
        input_frame.pack(pady=10)

        tk.Label(input_frame, text="Start Date (YYYY-MM-DD):", font=("Helvetica", 10)).grid(row=0, column=0, padx=5, pady=5)
        self.start_date_entry = tk.Entry(input_frame, width=15)
        self.start_date_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(input_frame, text="End Date (YYYY-MM-DD):", font=("Helvetica", 10)).grid(row=1, column=0, padx=5, pady=5)
        self.end_date_entry = tk.Entry(input_frame, width=15)
        self.end_date_entry.grid(row=1, column=1, padx=5, pady=5)

        # Generate Report Button
        generate_button = tk.Button(self.root, text="Generate Report", command=self.generate_report, bg="#007BFF", fg="white", font=("Helvetica", 12))
        generate_button.pack(pady=20)

    def generate_report(self):
        """Generate the rental report for the specified date range."""
        try:
            # Parse dates
            start_date = datetime.strptime(self.start_date_entry.get(), "%Y-%m-%d")
            end_date = datetime.strptime(self.end_date_entry.get(), "%Y-%m-%d")

            if start_date > end_date:
                raise ValueError("Start date must be before end date.")

            # Fetch rental data (mock data; replace with real database queries)
            data = self.fetch_rental_data(start_date, end_date)

            if not data:
                messagebox.showinfo("No Data", "No rental data found for the specified period.")
                return

            # Save the report or display
            save_to_csv = messagebox.askyesno("Save Report", "Do you want to save the report as a CSV file?")
            if save_to_csv:
                file_path = "rental_report.csv"
                with open(file_path, "w", newline="") as csvfile:
                    writer = csv.DictWriter(csvfile, fieldnames=data[0].keys())
                    writer.writeheader()
                    writer.writerows(data)
                messagebox.showinfo("Report Saved", f"Report saved to {file_path}.")
            else:
                # Display report in a new window
                self.show_report(data)

        except ValueError as e:
            messagebox.showerror("Invalid Input", f"Error: {str(e)}\nPlease enter valid dates in YYYY-MM-DD format.")

    def fetch_rental_data(self, start_date, end_date):
        """Mock function to fetch rental data. Replace with real database queries."""
        sample_data = [
            {"Rental ID": 1, "Customer": "John Doe", "Car": "Toyota Camry", "Date": "2024-11-01", "Amount": 200},
            {"Rental ID": 2, "Customer": "Jane Smith", "Car": "Honda Civic", "Date": "2024-11-05", "Amount": 150},
            {"Rental ID": 3, "Customer": "Bob Brown", "Car": "Tesla Model 3", "Date": "2024-11-10", "Amount": 300},
        ]
        return [
            record for record in sample_data
            if start_date <= datetime.strptime(record["Date"], "%Y-%m-%d") <= end_date
        ]

    def show_report(self, data):
        """Display the report in a new window."""
        report_window = tk.Toplevel(self.root)
        report_window.title("Rental Report")
        report_window.geometry("600x400")

        report_text = tk.Text(report_window, wrap="word", font=("Helvetica", 12))
        report_text.pack(expand=True, fill="both", padx=10, pady=10)

        report_text.insert("1.0", "Rental Report\n\n")
        for record in data:
            report_text.insert("end", f"Rental ID: {record['Rental ID']}\n")
            report_text.insert("end", f"Customer: {record['Customer']}\n")
            report_text.insert("end", f"Car: {record['Car']}\n")
            report_text.insert("end", f"Date: {record['Date']}\n")
            report_text.insert("end", f"Amount: ${record['Amount']}\n")
            report_text.insert("end", "-" * 50 + "\n")


# Run the app if this file is executed directly
if __name__ == "__main__":
    root = tk.Tk()
    # Example login state for testing
    login_state = {"is_logged_in": True, "role": "Admin", "username": "admin"}
    app = RentalReport(root, login_state)
    root.mainloop()