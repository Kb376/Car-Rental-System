import tkinter as tk
from tkinter import messagebox


class RentalReports:
    def __init__(self, root, is_logged_in, role):
        self.root = root
        self.root.title("Rental Reports")
        self.root.geometry("600x500")

        # Check if the user is logged in
        if not is_logged_in:
            messagebox.showerror("Access Denied", "You must log in to access this feature.")
            self.root.destroy()  # Close the window
            return

        self.role = role  # Admin or Staff role

        # Simulated rentals and revenue
        self.rentals = [
            {"car": "Toyota Camry", "rental_date": "2023-12-05", "return_date": "2023-12-10", "revenue": 300},
            {"car": "Honda Civic", "rental_date": "2023-12-15", "return_date": "2023-12-20", "revenue": 200},
            {"car": "Ford Focus", "rental_date": "2023-12-10", "return_date": "2023-12-12", "revenue": 150},
        ]
        self.all_cars = ["Toyota Camry", "Honda Civic", "Ford Focus", "Nissan Altima", "Chevrolet Malibu"]  # All cars in the system

        self.generate_reports_menu()

    def generate_reports_menu(self):
        """Show the menu for generating reports."""
        self.clear_screen()

        tk.Label(self.root, text="Rental Reports", font=("Arial", 16, "bold")).pack(pady=10)
        tk.Label(self.root, text=f"Logged in as: {self.role}", font=("Arial", 12)).pack(pady=5)

        tk.Label(self.root, text="Enter Start Date (YYYY-MM-DD):", font=("Arial", 12)).pack(pady=5)
        self.start_date_entry = tk.Entry(self.root)
        self.start_date_entry.pack(pady=5)

        tk.Label(self.root, text="Enter End Date (YYYY-MM-DD):", font=("Arial", 12)).pack(pady=5)
        self.end_date_entry = tk.Entry(self.root)
        self.end_date_entry.pack(pady=5)

        tk.Button(self.root, text="All Cars Rented", command=self.report_cars_rented).pack(pady=10)
        tk.Button(self.root, text="All Cars In-House", command=self.report_cars_in_house).pack(pady=10)
        tk.Button(self.root, text="Revenue Report", command=self.report_revenue).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.close_reports).pack(pady=10)

    def report_cars_rented(self):
        """Generate a report of all cars rented during the specified time."""
        start_date = self.start_date_entry.get().strip()
        end_date = self.end_date_entry.get().strip()

        if not start_date or not end_date:
            messagebox.showwarning("Input Error", "Please enter both start and end dates!")
            return

        results = [
            f"{rental['car']} (Rented: {rental['rental_date']} to {rental['return_date']})"
            for rental in self.rentals
            if not (end_date < rental["rental_date"] or start_date > rental["return_date"])
        ]

        self.show_results(f"Cars Rented from {start_date} to {end_date}", results)

    def report_cars_in_house(self):
        """Generate a report of all cars in-house during the specified time."""
        start_date = self.start_date_entry.get().strip()
        end_date = self.end_date_entry.get().strip()

        if not start_date or not end_date:
            messagebox.showwarning("Input Error", "Please enter both start and end dates!")
            return

        rented_cars = {
            rental["car"]
            for rental in self.rentals
            if not (end_date < rental["rental_date"] or start_date > rental["return_date"])
        }
        in_house_cars = set(self.all_cars) - rented_cars

        self.show_results(f"Cars In-House from {start_date} to {end_date}", list(in_house_cars))

    def report_revenue(self):
        """Generate a report of the revenue during the specified time."""
        start_date = self.start_date_entry.get().strip()
        end_date = self.end_date_entry.get().strip()

        if not start_date or not end_date:
            messagebox.showwarning("Input Error", "Please enter both start and end dates!")
            return

        total_revenue = sum(
            rental["revenue"]
            for rental in self.rentals
            if not (end_date < rental["rental_date"] or start_date > rental["return_date"])
        )

        self.show_results(
            f"Revenue from {start_date} to {end_date}", [f"Total Revenue: ${total_revenue}"]
        )

    def show_results(self, title, results):
        """Display the generated report."""
        self.clear_screen()

        tk.Label(self.root, text=title, font=("Arial", 14, "bold")).pack(pady=10)

        if results:
            for result in results:
                tk.Label(self.root, text=result, font=("Arial", 12)).pack(pady=5)
        else:
            tk.Label(self.root, text="No data found.", font=("Arial", 12), fg="red").pack(pady=10)

        tk.Button(self.root, text="Back", command=self.generate_reports_menu).pack(pady=20)

    def close_reports(self):
        """Close the reports section."""
        self.root.destroy()

    def clear_screen(self):
        """Clear the current screen."""
        for widget in self.root.winfo_children():
            widget.destroy()


# Run this file directly for testing
if __name__ == "__main__":
    from Login import CarRentalSystem  # Import your login system

    root = tk.Tk()
    login_app = CarRentalSystem(root)
    root.mainloop()

    if login_app.logged_in:  # Check login status
        role = login_app.users[login_app.username]["role"]  # Get user role
        root = tk.Tk()
        RentalReports(root, login_app.logged_in, role)
        root.mainloop()
