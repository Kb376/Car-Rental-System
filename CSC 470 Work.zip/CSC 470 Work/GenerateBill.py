import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta


class GenerateBill:
    def __init__(self, root, is_logged_in, role):
        self.root = root
        self.root.title("Generate Bill")
        self.root.geometry("600x500")

        # Check if the user is logged in
        if not is_logged_in:
            messagebox.showerror("Access Denied", "You must log in to access this feature.")
            self.root.destroy()  # Close the window
            return

        self.role = role  # Admin or Staff role

        # Simulated rental records
        self.rentals = [
            {"rental_id": "R001", "reservation_number": "RES1001", "car": "Toyota Camry", "due_date": "2023-12-10", "daily_rate": 50, "is_returned": False},
            {"rental_id": "R002", "reservation_number": "RES1002", "car": "Honda Civic", "due_date": "2023-12-15", "daily_rate": 40, "is_returned": False},
            {"rental_id": "R003", "reservation_number": "RES1003", "car": "Ford Focus", "due_date": "2023-12-12", "daily_rate": 45, "is_returned": False},
        ]

        self.bill_status = {}  # To track bill status (Paid/Unpaid)
        self.generate_bill_menu()

    def generate_bill_menu(self):
        """Display the main menu for generating bills."""
        self.clear_screen()

        tk.Label(self.root, text="Generate Bill for Returned Car", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(self.root, text="Enter Rental ID:", font=("Arial", 12)).pack(pady=5)
        self.rental_id_entry = tk.Entry(self.root)
        self.rental_id_entry.pack(pady=5)

        tk.Label(self.root, text="Enter Reservation Number:", font=("Arial", 12)).pack(pady=5)
        self.reservation_number_entry = tk.Entry(self.root)
        self.reservation_number_entry.pack(pady=5)

        tk.Button(self.root, text="Generate Bill", command=self.generate_bill).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.close_menu).pack(pady=10)

    def generate_bill(self):
        """Generate a bill for the provided Rental ID and Reservation Number."""
        rental_id = self.rental_id_entry.get().strip()
        reservation_number = self.reservation_number_entry.get().strip()

        if not rental_id or not reservation_number:
            messagebox.showwarning("Input Error", "Please enter both Rental ID and Reservation Number.")
            return

        rental = next(
            (
                rental
                for rental in self.rentals
                if rental["rental_id"] == rental_id and rental["reservation_number"] == reservation_number
            ),
            None,
        )

        if not rental:
            messagebox.showerror("Not Found", "Rental ID or Reservation Number not found.")
            return

        if rental["is_returned"]:
            messagebox.showinfo("Already Returned", f"The car ({rental['car']}) has already been returned.")
            return

        self.show_bill(rental)

    def show_bill(self, rental):
        """Display the bill for the rental."""
        self.clear_screen()

        tk.Label(self.root, text=f"Rental ID: {rental['rental_id']}", font=("Arial", 12)).pack(pady=5)
        tk.Label(self.root, text=f"Reservation Number: {rental['reservation_number']}", font=("Arial", 12)).pack(pady=5)
        tk.Label(self.root, text=f"Car: {rental['car']}", font=("Arial", 12)).pack(pady=5)
        tk.Label(self.root, text=f"Due Date: {rental['due_date']}", font=("Arial", 12)).pack(pady=5)

        # Calculate late fees if the car is returned late
        due_date = datetime.strptime(rental["due_date"], "%Y-%m-%d")
        return_date = datetime.now()
        late_days = (return_date - due_date).days
        late_fee = max(0, late_days) * rental["daily_rate"]

        tk.Label(self.root, text=f"Daily Rate: ${rental['daily_rate']}", font=("Arial", 12)).pack(pady=5)

        if late_fee > 0:
            tk.Label(self.root, text=f"Late Fee: ${late_fee} ({late_days} days late)", font=("Arial", 12), fg="red").pack(pady=5)
        else:
            tk.Label(self.root, text="No Late Fees", font=("Arial", 12), fg="green").pack(pady=5)

        # Total Bill
        total_bill = rental["daily_rate"] + late_fee
        self.bill_status[rental["rental_id"]] = {"amount": total_bill, "paid": False}

        tk.Label(self.root, text=f"Total Bill: ${total_bill}", font=("Arial", 12, "bold")).pack(pady=10)

        tk.Button(self.root, text="Mark as Paid", command=lambda: self.mark_bill_paid(rental)).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.generate_bill_menu).pack(pady=10)

    def mark_bill_paid(self, rental):
        """Mark the bill as paid."""
        rental_id = rental["rental_id"]
        if rental_id in self.bill_status:
            self.bill_status[rental_id]["paid"] = True
            rental["is_returned"] = True
            messagebox.showinfo("Payment Successful", f"The bill for {rental['car']} has been marked as paid.")
        else:
            messagebox.showerror("Error", "No bill found to mark as paid.")

        self.generate_bill_menu()

    def close_menu(self):
        """Close the Generate Bill menu."""
        self.root.destroy()

    def clear_screen(self):
        """Clear the current screen."""
        for widget in self.root.winfo_children():
            widget.destroy()


# Run this file directly for testing
if __name__ == "__main__":
    from Login import CarRentalSystem  # Import your login system

    root = tk.Tk()
    login_app = CarRentalSystem(root)
    root.mainloop()

    if login_app.logged_in:  # Check login status
        role = login_app.users[login_app.username]["role"]  # Get user role
        root = tk.Tk()
        GenerateBill(root, login_app.logged_in, role)
        root.mainloop()
