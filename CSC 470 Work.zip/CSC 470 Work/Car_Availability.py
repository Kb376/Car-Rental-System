import tkinter as tk
from tkinter import messagebox
from car_data import car_data  # Import car data


class CarAvailability:
    def __init__(self, root):
        self.root = root
        self.root.title("Check Car Availability")
        self.root.geometry("600x400")

        # Use imported car data
        self.cars = car_data

        self.main_menu()

    def main_menu(self):
        """Display the main menu for selecting a search type."""
        self.clear_screen()

        tk.Label(self.root, text="Check Car Availability", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Button(self.root, text="Search by Make", command=self.search_by_make).pack(pady=10)
        tk.Button(self.root, text="Search by Model", command=self.search_by_model).pack(pady=10)
        tk.Button(self.root, text="Search by Date Range", command=self.search_by_date).pack(pady=10)

    def search_by_make(self):
        """Show a page to select available makes."""
        self.clear_screen()

        tk.Label(self.root, text="Select a Make", font=("Arial", 14, "bold")).pack(pady=10)
        makes = sorted(set(car["make"] for car in self.cars))

        self.make_var = tk.StringVar(value="Select Make")
        tk.OptionMenu(self.root, self.make_var, *makes).pack(pady=10)

        tk.Button(self.root, text="Search", command=self.show_make_results).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.main_menu).pack(pady=10)

    def show_make_results(self):
        """Display results for the selected make."""
        selected_make = self.make_var.get()
        if selected_make == "Select Make":
            messagebox.showwarning("Selection Error", "Please select a make.")
            return

        results = [
            f"{car['make']} {car['model']} (Available: {car['available_from']} to {car['available_to']})"
            for car in self.cars if car["make"] == selected_make
        ]
        self.show_results(f"Cars for Make: {selected_make}", results)

    def search_by_model(self):
        """Show a page to select available models."""
        self.clear_screen()

        tk.Label(self.root, text="Select a Model", font=("Arial", 14, "bold")).pack(pady=10)
        models = sorted(set(car["model"] for car in self.cars))

        self.model_var = tk.StringVar(value="Select Model")
        tk.OptionMenu(self.root, self.model_var, *models).pack(pady=10)

        tk.Button(self.root, text="Search", command=self.show_model_results).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.main_menu).pack(pady=10)

    def show_model_results(self):
        """Display results for the selected model."""
        selected_model = self.model_var.get()
        if selected_model == "Select Model":
            messagebox.showwarning("Selection Error", "Please select a model.")
            return

        results = [
            f"{car['make']} {car['model']} (Available: {car['available_from']} to {car['available_to']})"
            for car in self.cars if car["model"] == selected_model
        ]
        self.show_results(f"Cars for Model: {selected_model}", results)

    def search_by_date(self):
        """Show a page to enter a date range."""
        self.clear_screen()

        tk.Label(self.root, text="Enter Start Date (YYYY-MM-DD)", font=("Arial", 14, "bold")).pack(pady=10)
        self.start_date_entry = tk.Entry(self.root)
        self.start_date_entry.pack(pady=5)

        tk.Label(self.root, text="Enter End Date (YYYY-MM-DD)", font=("Arial", 14, "bold")).pack(pady=10)
        self.end_date_entry = tk.Entry(self.root)
        self.end_date_entry.pack(pady=5)

        tk.Button(self.root, text="Search", command=self.show_date_results).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.main_menu).pack(pady=10)

    def show_date_results(self):
        """Display results for the entered date range."""
        start_date = self.start_date_entry.get().strip()
        end_date = self.end_date_entry.get().strip()

        if not start_date or not end_date:
            messagebox.showwarning("Input Error", "Please enter both a start date and an end date.")
            return

        results = [
            f"{car['make']} {car['model']} (Available: {car['available_from']} to {car['available_to']})"
            for car in self.cars if not (end_date < car["available_from"] or start_date > car["available_to"])
        ]
        self.show_results(f"Cars Available from {start_date} to {end_date}", results)

    def show_results(self, title, results):
        """Display the search results."""
        self.clear_screen()

        tk.Label(self.root, text=title, font=("Arial", 14, "bold")).pack(pady=10)

        if results:
            for result in results:
                tk.Label(self.root, text=result, font=("Arial", 12)).pack(pady=5)
        else:
            tk.Label(self.root, text="No cars found.", font=("Arial", 12), fg="red").pack(pady=10)

        tk.Button(self.root, text="Back", command=self.main_menu).pack(pady=20)

    def clear_screen(self):
        """Clear the current screen."""
        for widget in self.root.winfo_children():
            widget.destroy()


# Run this file directly for testing
if __name__ == "__main__":
    root = tk.Tk()
    app = CarAvailability(root)
    root.mainloop()